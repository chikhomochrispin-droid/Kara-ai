const express = require('express');
const cors = require('cors');
const { OpenAI } = require('openai');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

app.post('/chat', async (req, res) => {
  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{ role: 'user', content: req.body.message }]
  });

  res.json({ reply: response.choices[0].message.content });
});

app.post('/image', async (req, res) => {
  const img = await openai.images.generate({
    prompt: req.body.prompt,
    size: '1024x1024'
  });

  res.json({ url: img.data[0].url });
});

app.listen(5000, () => console.log('Server running'));