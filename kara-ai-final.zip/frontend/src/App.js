import { useState } from 'react';
import axios from 'axios';

export default function App() {
  const [msg, setMsg] = useState('');
  const [chat, setChat] = useState([]);

  const send = async () => {
    const res = await axios.post('http://localhost:5000/chat', { message: msg });

    setChat([...chat, { user: msg, ai: res.data.reply }]);
    setMsg('');
  };

  return (
    <div style={{ padding: 20, background: '#111', color: '#fff', minHeight: '100vh' }}>
      <h1>Kara.ai</h1>

      <div style={{ height: 300, overflow: 'auto', border: '1px solid gray' }}>
        {chat.map((c, i) => (
          <div key={i}>
            <p>You: {c.user}</p>
            <p>AI: {c.ai}</p>
          </div>
        ))}
      </div>

      <input value={msg} onChange={(e) => setMsg(e.target.value)} />
      <button onClick={send}>Send</button>
    </div>
  );
}